<footer class="limpar mg-t-8">
    <div class="container">
        <div class="box-12 pd-t-3">
            <p class="txt-c fonte12"> &copy; 2024 - Todos os direitos reservados </p>
        </div>
    </div>
</footer>

</body>
</html>