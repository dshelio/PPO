<?php 


interface PagamentoInterface
{
     public function pagar($valor);
}